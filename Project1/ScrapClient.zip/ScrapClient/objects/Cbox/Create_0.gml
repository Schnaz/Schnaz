/// @description Insert description here
// You can write your code in this editor
image_speed=0;
check=-1;




